# site-operacoes
Atividade assíncrona envolvendo as disciplinas de Desenvolvimento de Software em Nuvem e Ambientes de Desenvolvimento de Software
